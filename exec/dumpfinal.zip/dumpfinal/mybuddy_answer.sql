-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 3.35.238.205    Database: mybuddy
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answer` (
  `answerID` int NOT NULL AUTO_INCREMENT,
  `content` varchar(200) DEFAULT NULL,
  `childrenID` int NOT NULL,
  `questionID` int NOT NULL,
  `isUsed` tinyint DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  PRIMARY KEY (`answerID`),
  KEY `fk_Answer_Children1_idx` (`childrenID`),
  KEY `fk_answer_question1_idx` (`questionID`),
  CONSTRAINT `fk_Answer_Children1` FOREIGN KEY (`childrenID`) REFERENCES `children` (`childrenID`) ON DELETE CASCADE,
  CONSTRAINT `fk_answer_question1` FOREIGN KEY (`questionID`) REFERENCES `question` (`questionID`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (16,'안녕! 오늘뭐했어?',10,1,0,'2022-08-18 07:23:37'),(17,'치료받느라 고생했어!',10,1,0,'2022-08-18 07:23:37'),(18,'얼른 나아서 다같이 즐거운 여행을 떠나자!',10,1,0,'2022-08-18 07:23:37'),(19,'오늘 많이 힘들었지? 수고했어 세상에서 랑이가 제일 멋져~!!',10,1,0,'2022-08-18 07:23:37'),(20,'병원에서 힘든일은 없니!? 내가 도와줄게!!',10,1,0,'2022-08-18 07:23:37'),(23,'안녕 랑이야! 오늘도 수고했어!! 다나으면 같이 여행가자!!!',13,1,0,'2022-08-18 07:48:31'),(24,'프로젝트 하느라 고생했어. 특화도 해야하네',1,1,0,'2022-08-18 07:48:37'),(25,'배고프다. 빨리 끝내고 밥먹고싶다.',1,1,0,'2022-08-18 07:48:37'),(26,'안녕 구미2반 8팀 화이팅!!!!!',1,1,0,'2022-08-18 07:48:53'),(27,'자식농사 잘못했네',14,1,0,'2022-08-18 13:37:28');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  3:18:45
